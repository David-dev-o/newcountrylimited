<?php
session_start();
$password = "admin123";
$uploadDir = "img/portfolio/";

if (isset($_POST['password']) && $_POST['password'] === $password) {
    $_SESSION['admin'] = true;
}

if (isset($_FILES['image']) && isset($_SESSION['admin'])) {
    $name = basename($_FILES['image']['name']);
    $target = $uploadDir . $name;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        echo "<p class='message success'>Uploaded successfully.</p>";
        file_put_contents("portfolio-data.txt", $name . "\n", FILE_APPEND);
    } else {
        echo "<p class='message error'>Upload failed.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Upload</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f4f4;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .upload-box {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      width: 300px;
      text-align: center;
    }

    h2 {
      margin-bottom: 20px;
      color: #333;
    }

    input[type="password"],
    input[type="file"] {
      width: 90%;
      padding: 10px;
      margin: 10px 0;
    }

    button {
      padding: 10px 20px;
      background: #4b6cb7;
      color: white;
      border: none;
      cursor: pointer;
      border-radius: 5px;
    }

    button:hover {
      background: #182848;
    }

    .message {
      margin: 10px 0;
      padding: 10px;
      border-radius: 5px;
    }

    .success {
      background: #d4edda;
      color: #155724;
    }

    .error {
      background: #f8d7da;
      color: #721c24;
    }
  </style>
</head>
<body>
  <div class="upload-box">
    <h2>Admin Upload Page</h2>

    <?php if (!isset($_SESSION['admin'])): ?>
      <form method="POST">
        <input type="password" name="password" placeholder="Enter password" required><br>
        <button type="submit">Enter</button>
      </form>
    <?php else: ?>
      <form method="POST" enctype="multipart/form-data">
        <input type="file" name="image" accept="image/*" required><br>
        <button type="submit">Upload</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
